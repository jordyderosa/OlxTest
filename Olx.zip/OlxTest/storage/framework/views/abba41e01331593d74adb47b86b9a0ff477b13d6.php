<!DOCTYPE html>
<html>
  <head>
      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
      <title>Upload File Page</title>
  </head>
  <body>
      <div class="container">
          <?php echo $__env->yieldContent('content'); ?>
      </div>
  </body>
</html>
