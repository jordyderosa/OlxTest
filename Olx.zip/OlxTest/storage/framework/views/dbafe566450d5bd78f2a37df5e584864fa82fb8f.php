<?php $__env->startSection('content'); ?>
    <h2>Upload File Here</h2>


    <?php echo Form::open(array('url'=> '/handleUpload','files'=>true)); ?>


        <?php echo Form::file('file'); ?>

        <?php echo Form::token(); ?>

        <?php echo Form::submit('Upload'); ?>



    <?php echo Form::close(); ?>


    <h2>Check Number Tool</h2>
    <?php echo Form::open(array('url'=> '/checkNumber')); ?>


        <?php echo Form::label('number', 'Mobile Number'); ?>

        <?php echo Form::text('number'); ?>

        <?php echo Form::token(); ?>

        <?php echo Form::submit('Check Number'); ?>



    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>